from turtle import Screen
from Paddle import paddle
from Ball import ball
import time
from Scoreboared import score
screen = Screen()
screen.bgcolor('black')
screen.setup(800, 600)
screen.title('Pong')
screen.tracer(0)
r_Paddle = paddle((350, 0))
l_Paddle = paddle((-350, 0))
ball = ball()
score = score()


screen.listen()
screen.onkey(r_Paddle.go_up, 'Up')
screen.onkey(r_Paddle.go_down, 'Down')
screen.onkey(l_Paddle.go_up, 'w')
screen.onkey(l_Paddle.go_down, 's')

Game_is_on = True
while Game_is_on:
    time.sleep(ball.movesspeed)
    screen.update()
    ball.move()
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()
    if (ball.distance(r_Paddle) < 50 and ball.xcor() > 320
            or ball.distance(l_Paddle) < 50 and ball.xcor() < -320):
        ball.bounce_x()
    if ball.xcor() > 380:
        ball.reset_game()
        score.l_point()
    if ball.xcor() < -380:
        ball.reset_game()
        score.r_point()

screen.exitonclick()
