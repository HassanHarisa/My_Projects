import json
from tkinter import *
from tkinter import messagebox
import random
# ---------------------------- PASSWORD GENERATOR ------------------------------- #


def generate_password():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
               'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)
    password_letters = [random.choice(letters) for _ in range(nr_letters)]
    password_symbols = [random.choice(symbols) for _ in range(nr_symbols)]
    password_numbers = [random.choice(numbers) for _ in range(nr_numbers)]
    password_list = password_letters + password_symbols + password_numbers
    random.shuffle(password_list)
    password = "".join(password_list)
    password_entry.insert(0, password)
# ---------------------------- SAVE PASSWORD ------------------------------- #


def save():
    new_data = {
        website_entry.get(): {'email': email_entry.get(),
                              'password': password_entry.get()

        }
    }
    if len(website_entry.get()) == 0 or len(password_entry.get()) == 0:
        messagebox.showinfo(title="Oops", message='Please fill the empty fields :)')
    else:
        is_ok = messagebox.askokcancel(title=website_entry.get(),
                                       message=f'These are the details entered: \nEmail: {email_entry.get()}\npassword:'
                                               f' {password_entry.get()}\n'
                                               f'is it ok to save?', )
        if is_ok:
            try:
                with open('data.json', 'r') as datafile:
                    data = json.load(datafile)
            except FileNotFoundError:
                with open('data.json', 'w') as datafile:
                    json.dump(data, datafile, indent=4)
            else:
                data.update(new_data)
                with open('data.json', 'w') as datafile:
                    json.dump(data, datafile, indent=4)
            finally:

                messagebox.showinfo(message="your data has been saved in your json file", title='data saved')
                website_entry.delete(0, END)
                password_entry.delete(0, END)

def find_password():
    try:
        with open('data.json')as datafile:
            data = json.load(datafile)
    except FileNotFoundError:
        messagebox.showinfo(title='Error', message="No data file found")
    else:
        if website_entry.get() in data:
            email = data[website_entry.get()]['email']
            password = data[website_entry.get()]['password']
            messagebox.showinfo(title=website_entry.get(), message=f'email: {email}\n password: {password}')
        else:
            messagebox.showinfo(title='Error',  message=f'No data for {website_entry.get()} is found')

# ---------------------------- UI SETUP ------------------------------- #


window = Tk()
window.title('Password Manager')
window.config(padx=100, pady=100)
canvas = Canvas(width=200, height=200)
Photo = PhotoImage(file='logo.png')
image = canvas.create_image(100, 100, image=Photo)
canvas.grid(column=1, row=0)
website_label = Label(text='Website:')
website_label.grid(column=0, row=1)
emai_label = Label(text='Email/Username:')
emai_label.grid(column=0, row=2)
Password_label = Label(text="Password")
Password_label.grid(column=0, row=3)
website_entry = Entry(width=21)
website_entry.focus()
website_entry.grid(column=1, row=1)
email_entry = Entry(width=35)
email_entry.insert(0, 'Hassanwaleed222@gmail.com')
email_entry.grid(column=1, row=2, columnspan=2)
password_entry = Entry(width=21)
password_entry.grid(column=1, row=3,)
Generate_password_button = Button(text='Generate Password', command=generate_password)
Generate_password_button.grid(column=2, row=3)
Add_button = Button(text='Add', width=36, command=save)
Add_button.grid(column=1, row=4, columnspan=2)
search_button = Button(text='Search', command=find_password)
search_button.grid(row=1, column=2)
window.mainloop()
